<?php 

    //DAYS

    $M_ = isset($_POST["M"]) ? $_POST["M"] : '';
    $T_ = isset($_POST["T"]) ? $_POST["T"] : '';
    $W_ = isset($_POST["W"]) ? $_POST["W"] : '';
    $H_ = isset($_POST["H"]) ? $_POST["H"] : '';
    $F_ = isset($_POST["F"]) ? $_POST["F"] : '';

    $CourseNumber = isset($_POST["courseNum"]) ? $_POST["courseNum"] : '';
    
    //Validate Course Number 
    // if (!validCRN($CourseNumber))
    //     header('Location: time.php');



    $origTimeStart = isset($_POST["testTimeStart"]) ? $_POST["testTimeStart"] : '';
    $origTimeEnd = isset($_POST["testTimeEnd"]) ? $_POST["testTimeEnd"] : '';

    $testTimeStart  = date("Hi", strtotime($origTimeStart));
    $testTimeEnd  = date("Hi", strtotime($origTimeEnd));

    // echo "hksjlfkjsklfjskjfksjfkjsklfjkl";
    // echo $testTimeStart;
    // echo "<br>";
    // echo $testTimeEnd;

?>

<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8' />
<link href='fullcalendar-2.1.1/fullcalendar.css' rel='stylesheet' />
<link href='fullcalendar-2.1.1/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src='fullcalendar-2.1.1/lib/moment.min.js'></script>
<script src='fullcalendar-2.1.1/lib/jquery.min.js'></script>
<script src='fullcalendar-2.1.1/fullcalendar.js'></script>

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<link href="style.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Muli' rel='stylesheet' type='text/css'>
<!-- <script src="js/book-script.js"></script> -->
<!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css"> -->
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<!-- Optional theme -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css">
<!-- Latest compiled and minified JavaScript -->

<script type="text/javascript" src="loginCheck.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>-->
<script>

        $(document).ready(function() {
        
        $('#calendar').fullCalendar({
            header: {
                left: '',
                center: '',
                right: 'title month,agendaWeek,agendaDay prev,next'
            },
            isCustom: true,
            weekends: false,
            defaultDate: null,
            editable: true,
            eventLimit: true, // allow "more" link when too many events
            <?
            // include('phpcode/convert_time.php');
            // include('phpcode/time_conflicts.php');
            require_once('phpcode/convert_time.php');
                // echo "hello";
            if (!validCRN($CourseNumber))
                header('Location: time.php');
            if(!inValidSITC($CourseNumber))
                header('Location: time.php');

                // echo validCRN($CourseNumber);
            // require_once('DBQuery.php');


            $M = 'M';
            $T = 'T';
            $W = 'W';
            $H = 'R';
            $F = 'F';

            // $crn = 11069; // se
            $crn = $CourseNumber;
            $time = $testTimeStart;
            $end_time = $testTimeEnd;

            $temp_arr = getBannerIds($crn,$time,$end_time,$M,$T,$W,$H,$F);

            $q_res = getStudentsWithBanner($temp_arr,$time,$end_time,$crn,$M,$T,$W,$H,$F);

            // $row = $q_res->fetch_assoc();
            //input
            // $M_ = 'M';
            // $T_ = '';
            // $W_ = 'W';
            // $H_ = '';
            // $F_ = 'F';
            createEvents($q_res,$time,$end_time,$M_,$T_,$W_,$H_,$F_);
            ?>
            //https://code.google.com/p/fullcalendar/issues/detail?id=236
            eventRender: function(calEvent, element, view) {
            if(calEvent.room) {
                element[0].innerHTML = element[0].innerHTML.replace(calEvent.title,'<div class="roomNum">'+calEvent.room+'</div>'+calEvent.title);
          }
        }
     });  
});

</script>
</head>
<body>
<div class="container">                                          
    <div id='calendar'></div>
    <form id="table_form" action="phpcode/show_conflicts.php" method="POST" >
        <input type="hidden" name="start_time" value=<? echo '"'; echo $testTimeStart;  echo'"' ?>  />
        <input type="hidden" name="end_time" value=<? echo '"'; echo $testTimeEnd;  echo'"' ?>/>
        <input type="hidden" name="class_crn" value=<? echo '"'; echo $CourseNumber;  echo'"' ?>/>

        <input type="hidden" name="monday" value=<? echo '"'; echo $M_;  echo'"' ?>/>
        <input type="hidden" name="tuesday" value=<? echo '"'; echo $T_;  echo'"' ?>/>
        <input type="hidden" name="wednesday" value=<? echo '"'; echo $W_;  echo'"' ?>/>
        <input type="hidden" name="thursday" value=<? echo '"'; echo $H_;  echo'"' ?>/>
        <input type="hidden" name="friday" value=<? echo '"'; echo $F_;  echo'"' ?>/>

        <a class="btn btn-lg btn-primary btn-block" type="submit" onclick="document.forms['table_form'].submit();" value="Submit" id="calButton" href="#" >Show Students</a>
    <!-- <input type="submit" value="Submit" onClick="javascript:myfunc()"/> -->
    </form>

    <a class="btn btn-lg btn-primary btn-block" id="calButton" href="time.php">Test New Class</a>
</div>

</body>
</html>
