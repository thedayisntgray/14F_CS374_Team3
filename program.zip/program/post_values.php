<?php
	////////////////FETCHES VALUES FROM THE INPUT PAGE///////////////////////
	//POST IS WHAT YOU USE TO GET THE VALUES('NAME' IN HTML) FROM THE HTML PAGE
	//GO TO LINE 66 AND LOOK FOR 'ACTION.' CHANGE THE VALUE TO THE FILE YOU WANT TO SEND THE VALUES TO
	//COURSE NUM/CRN VALUE
	echo $_POST['courseNum']."<br>";
	
	//GRADUATE REQUIRED
	if (isset($_POST['gradReq'])){
		echo "Graduated required.<br>";
	}
	else{
		echo "Graduated not required.<br>";
	}
	
	//INSTRUCTOR
	echo $_POST['instructor']."<br>";
	
	//ROOM CAPACTIY
	echo $_POST['rmCapacity']."<br>";
	
	//DAYS
	$M='none';
	$T='none';
	$W='none';
	$R='none';
	$F='none';
	if (isset($_POST['testDay'])){
		//LOOP LOOKING FOR ALL DAYS CHECKED, THEN STORE THEM IN THE DAY VALUES ABOVE
		for ($i = 0; $i < count($_POST['testDay']); $i++){
			if ($_POST['testDay'][$i]=='M'){
				$M = $_POST['testDay'][$i];
			}
			else if ($_POST['testDay'][$i]=='T'){
				$T = $_POST['testDay'][$i];
			}
			else if ($_POST['testDay'][$i]=='W'){
				$W = $_POST['testDay'][$i];
			}
			else if ($_POST['testDay'][$i]=='R'){
				$R = $_POST['testDay'][$i];
			}
			else if ($_POST['testDay'][$i]=='F'){
				$F = $_POST['testDay'][$i];
			}
		}
	}
	echo "Monday: ".$M."<br>";
	echo "Tuesday: ".$T."<br>";
	echo "Wednesday: ".$W."<br>";
	echo "Thursday: ".$R."<br>";
	echo "Friday: ".$F."<br>";
	
	//TIME
	echo $_POST['testTime']."<br>";
	
	//COMPUTER LAB REQUIREMENT
	if (isset($_POST['compLab'])){
		echo $_POST['compLab']."<br>";
	}
	else{
		echo "Computer Lab not required.<br>";
	}
	///////////////////////////////////////////////////////////////////////
?>