<?php
	require_once('DBQuery.php');
	
	//return array of banner numbers
	function getBannerIds($CRN,$time,$end_time,$M,$T,$W,$H,$F){
		$query = "SELECT * FROM `table 1` WHERE (`Begin Time 1` >= '" . $time ."' AND `End Time1` <= '". $end_time ."' ) AND ( `CRN` = " .$CRN." ) 
				  AND (Monday='".$M."' OR Tuesday='".$T."'
				  OR Wednesday= '".$W."' OR Thursday='".$H."'
				  OR Friday='".$F."') ORDER BY `Last Name`";
		
		$search = new DBQuery($query);
		$search->execute_query();
		$IDs = $search->get_result();
		$search->close();

		// echo 'hello';
		$banner_arr = array();
		$num_results = $IDs->num_rows;

		for ($i=0; $i <$num_results; $i++)
		{
			$row = $IDs->fetch_assoc();
			$banner_arr[] = $row['Banner ID'];
			// echo $banner_arr[$i];
			// echo '<br>';

		}
		$IDs->free();
		return $banner_arr;
		
	}

	function getStudentsWithBanner($banner_arr,$exclude_crn = nil,$M = nil,$T = nil,$W = nil,$H = nil,$F = nil){

		$number_of_rows = count($banner_arr);
		$sql_cond = "";
		if ($number_of_rows != 0){
			for($i=0; $i < $number_of_rows; $i++)
			{
				$temp = "`Banner ID` = '" . $banner_arr[$i] . "' ";
				if ($i < $number_of_rows - 1)
					$temp = $temp . " OR ";
				$sql_cond = $sql_cond . $temp;
			}
		}

		else $sql_cond = "1 = 1";
		$query = "SELECT `CRN`, `Course Number`, count(CRN), `Course Title`, `Begin Time 1`,
		`Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday` FROM `table 1` 
			WHERE ( `CRN` <> " . $exclude_crn ." ) 
			AND (" . $sql_cond . ")
			AND (Monday='".$M."' AND Tuesday ='".$T."'
				  AND Wednesday= '".$W."' AND Thursday='".$H."'
				  AND Friday='".$F."') 
			GROUP BY `CRN` ORDER BY `Begin Time 1` limit 10";
		// echo $query;

		$search = new DBQuery($query);
		$search->execute_query();
		$result = $search->get_result();
		$search->close();
		return $result;
	}

 

	// echo "helloworld";
	// $banner_arr = array();


	// $temp_arr = getBannerIds($crn,$time,$end_time,$M,$T,$W,$H,$F);
	// $q_res = getStudentsWithBanner($temp_arr,$crn,$M,'',$W,'',$F);
	// $row = $q_res->fetch_assoc();
	// echo $row['Course Number'];

	// echo '<br>';
?>