<?php
	require_once('convert_time.php');

	$M = isset($_POST["monday"]) ? $_POST["monday"] : '';
    $T = isset($_POST["tuesday"]) ? $_POST["tuesday"] : '';
    $W = isset($_POST["wednesday"]) ? $_POST["wednesday"] : '';
    $H = isset($_POST["thursday"]) ? $_POST["thursday"] : '';
    $F = isset($_POST["friday"]) ? $_POST["friday"] : '';


	$time = isset($_POST["start_time"]) ? $_POST["start_time"] : '';
    $end_time = isset($_POST["end_time"]) ? $_POST["end_time"] : '';


	$crn = isset($_POST["class_crn"]) ? $_POST["class_crn"] : '';

	// echo "starttime and endtime are: " . $time . "and " . $end_time . "crn " . $crn;

	$color = '';
	//The current color to be used for a day, it depends on the highest classification
	$max_importance = 0;
	$current = 0;

function getDistinctStudentsWithBanner($banner_arr,$time, $end_time, $exclude_crn = nil,$M = nil,$T = nil,$W = nil,$H = nil,$F = nil){
    $number_of_rows = count($banner_arr);
  
    $sql_cond = "";
    if ($number_of_rows > 0){
        for($i=0; $i < $number_of_rows  ; $i++)
        {
            $temp = "`Banner ID` = '" . $banner_arr[$i] . "' ";
            if ($i < $number_of_rows - 1  )
                $temp = $temp . " OR ";
            $sql_cond = $sql_cond . $temp;
        }
    }
    else $sql_cond = "1 = 1";
    $query = "SELECT * FROM (SELECT * FROM `table 1` as subT WHERE ( `CRN` <> " . $exclude_crn ." ) 
    	AND (" . $sql_cond . ")
        AND (Monday= '".$M."' OR Tuesday ='".$T."' 
              AND Wednesday= '".$W."'  OR Thursday= '".$H."'
              AND Friday= '".$F."')
        AND ((`Begin Time 1` >= " . $time ." AND `Begin Time 1` <= " . $end_time .") OR (`End Time1` >= " . $time ." AND `End Time1` <= " . $end_time ."))
        AND (Major = 'Computer Science' OR Major = 'Information Technology' OR 'Information Systems')
        ORDER BY find_in_set(Classification, 'Senior,Junior,Sophomore,Freshman')  ) 
        as T GROUP BY `Banner ID` ORDER BY find_in_set(Classification, 'Senior,Junior,Sophomore,Freshman') ";

        // SELECT DISTINCT * FROM (SELECT * FROM `table 1` as subT WHERE ( `CRN` <> 11069 )
        // AND (`Banner ID` = '347678'  OR `Banner ID` = '867548'  OR `Banner ID` = '578596'  OR `Banner ID` = '68223'  OR `Banner ID` = '563126'  OR `Banner ID` = '184688'  OR `Banner ID` = '844742'  OR `Banner ID` = '598516'  OR `Banner ID` = '613503'  OR `Banner ID` = '816062'  OR `Banner ID` = '421919'  OR `Banner ID` = '271802'  OR `Banner ID` = '144826' )
        // AND (Monday='M' OR Tuesday ='T'
        //       OR Wednesday= 'W' OR Thursday='H'
        //       OR Friday='F') ORDER BY find_in_set(Classification, 'Senior,Junior,Sophomore,Freshman')  ) as T GROUP BY `CRN` ORDER BY find_in_set(Classification, 'Senior,Junior,Sophomore,Freshman')
        

    // echo $query;
    $search = new DBQuery($query);
    $search->execute_query();
    $result = $search->get_result();
    $search->close();

    return $result;
}

	//Searches for Time conflicts
    $temp_arr = getBannerIds($crn,$time,$end_time,$M,$T,$W,$H,$F);

	$timeConflicts = getDistinctStudentsWithBanner($temp_arr,$time,$end_time,$crn,$M,$T,$W,$H,$F);


	//NO TIME CONFLICT OCCURRING
	if ( 0 == $timeConflicts->num_rows){
		echo 'No time conflict.';
		$color = 'white';
	}
	//IF THERE ARE TIME CONFLICTS, THE SYSTEM WILL DISPLAY THE CONFLICTED STUDENTS
	//  WITH THEIR CONFLICTED CLASSES
	else {
		$num_results = $timeConflicts->num_rows;
        $crn1 = array();
        $count = 0;
        $max_count = 0;
        $current_crn = 0;

		echo '<table border="1" style="width:50%">';
		for ($i=0; $i < $num_results; $i++)
		{
			$row = $timeConflicts->fetch_assoc();

			if ( $row['Classification'] == "Senior"){
				echo '<tr bgcolor="#FF0000" ><td><b>Name:</b></td><td>'.$row['First Name'].'</td> <td>'.$row['Last Name'].'</td></tr>';
				echo '<tr bgcolor="#FF0000" ><td>Classification:</td><td>'.$row['Classification'].'</td></tr>';
				echo '<tr bgcolor="#FF0000" ><td>Major:</td><td>'.$row['Major'].'</td></tr>';
			}
			else{
				echo '<tr><td><b>Name:</b></td><td>'.$row['First Name'].'</td> <td>'.$row['Last Name'].'</td></tr>';
				echo '<tr><td>Classification:</td><td>'.$row['Classification'].'</td></tr>';
				echo '<tr><td>Major:</td><td>'.$row['Major'].'</td></tr>';
			}


		}
		echo '</table>';
		$timeConflicts->free();
	}
	echo "<br>";
	echo "Number of results " . $num_results;

	
	
?>