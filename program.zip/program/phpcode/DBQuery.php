<?php
	class DBQuery {
		private $query;
		private $result;
		private $error;
		private $db;
		
		public function DBQuery($q){
			$this->db = new mysqli('localhost', 'root', '', 'full_conflicts');
			if (mysqli_connect_errno()){
				$this->error = mysqli_connect_error();
				echo "Error: connection to database failed %s\n ".$this->error;
				exit();
			}
			$this->query = $q;
		}
		
		public function execute_query(){
			$this->result = $this->db->query($this->query);
		}
		
		public function get_result(){
			return $this->result;
		}
		
		public function close(){
			$this->db->close();
		}
	}

	
?>