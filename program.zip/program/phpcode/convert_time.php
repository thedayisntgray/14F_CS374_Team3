<?
require_once('DBQuery.php');

$t = 1335;

function validCRN($crn){
    $query = "SELECT `CRN` FROM `table 1` WHERE CRN = '" . $crn . "' limit 1";
    // echo $query;
    $search = new DBQuery($query);
    $search->execute_query($query);
    $result = $search->get_result();
    $row_count = $result->num_rows;
    $search->close();

return $row_count;
}

function inValidSITC($crn){
    $query = "SELECT `Pidm`, `Term Code`, `Part of Term`, `Major`, `Classification`, `CRN`, `Subject`, `Course Number`, `Section Number`, `Course Title`, `Instructor Name`, `Banner ID`, `First Name`, `Last Name`, `Middle Name`, `Preferred First Name`, `ACU Email Address`, `Begin Time 1`, `End Time1`, `Bldg Code`, `Room Code`, `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`, `Sunday`, `Minor One`, `Minor Two`, `Section Max Enrollment`, `Section Enrollment`, `Section Available Seats` 
            FROM `table 1` WHERE  ( `CRN` = " .$crn ." ) 
              AND (Monday='M' OR Tuesday='T'
              OR Wednesday= 'W' OR Thursday='R'
              OR Friday='F')
              AND (Major = 'Computer Science' OR Major = 'Information Technology' OR 'Information Systems') 
              ORDER BY `Last Name` ";
              // echo $query;
    $search = new DBQuery($query);
    $search->execute_query($query);
    $result = $search->get_result();
    $row_count = $result->num_rows;
    $search->close();

return $row_count;
}

//function converts military time stored as int to iso time
function intToISO($time){

  $ISO_t = gmdate ( "H:i:s", floor($time/100)*3600 + ($time - floor($time/100)*100)*60 );
  return 'T' . $ISO_t;
}

//hour min second month day year                                N = 1 (for Monday) through 7 (for Sunday)
$h = mktime(0, 0, 0, 10, 31, 2008); $d = date("Y-n-j", $h) ; $w= date("N", $h) ;

$format = date();

//increment date
// $date in xxxx-xx-xx format
$ddd = '2014-08-10';
function incrementStartTime($date,$num_time=nil){
    $_date = date_create($date);
        date_modify($_date, '+1 day');
        return date_format($_date, 'Y-m-d');
}

//return array of banner numbers
function getBannerIds($CRN,$time,$end_time,$M,$T,$W,$H,$F){
    $query = "SELECT `Pidm`, `Term Code`, `Part of Term`, `Major`, `Classification`, `CRN`, `Subject`, `Course Number`, `Section Number`, `Course Title`, `Instructor Name`, `Banner ID`, `First Name`, `Last Name`, `Middle Name`, `Preferred First Name`, `ACU Email Address`, `Begin Time 1`, `End Time1`, `Bldg Code`, `Room Code`, `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`, `Sunday`, `Minor One`, `Minor Two`, `Section Max Enrollment`, `Section Enrollment`, `Section Available Seats` 
            FROM `table 1` WHERE  ( `CRN` = " .$CRN." ) 
              AND (Monday='M' OR Tuesday='T'
              OR Wednesday= 'W' OR Thursday='R'
              OR Friday='F')
              AND (Major = 'Computer Science' OR Major = 'Information Technology' OR 'Information Systems') 
              ORDER BY `Last Name` ";

              // echo $query;
    //AND (Major = 'Computer Science' OR Major = 'Information Technology' OR 'Information Systems') 

    // $query = "SELECT * FROM `table 1` WHERE (`CRN` = ".$CRN.") AND (";
    $search = new DBQuery($query);
    $search->execute_query();
    $result = $search->get_result();
    $num_results = $result->num_rows;

    $search->close();

    $banner_arr = array();

    for ($i=0; $i < $num_results; $i++)
    {
        $row = $result->fetch_assoc();
        $banner_arr[] = $row['Banner ID'];

    }
    // echo count($banner_arr);
    $result->free();
    return $banner_arr;
}
                                //bannar array is empty
function getStudentsWithBanner($banner_arr,$time, $end_time, $exclude_crn = nil,$M = nil,$T = nil,$W = nil,$H = nil,$F = nil){
    $number_of_rows = count($banner_arr);
  
    $sql_cond = "";
    if ($number_of_rows > 0){
        for($i=0; $i < $number_of_rows  ; $i++)
        {
            $temp = "`Banner ID` = '" . $banner_arr[$i] . "' ";
            if ($i < $number_of_rows - 1  )
                $temp = $temp . " OR ";
            $sql_cond = $sql_cond . $temp;
        }
    }
    else $sql_cond = "1 = 1";
    $query = "SELECT DISTINCT * FROM (SELECT * FROM `table 1` as subT WHERE ( `CRN` <> " . $exclude_crn ." ) 
        AND (" . $sql_cond . ")
        AND (Monday='M' OR Tuesday ='T'
              OR Wednesday= 'W' OR Thursday='R'
              OR Friday='F') 
        ORDER BY find_in_set(Classification, 'Senior,Junior,Sophomore,Freshman')  ) 
        as T GROUP BY `CRN` ORDER BY find_in_set(Classification, 'Senior,Junior,Sophomore,Freshman') ";


        // SELECT DISTINCT * FROM (SELECT * FROM `table 1` as subT WHERE ( `CRN` <> 11069 )
        // AND (`Banner ID` = '347678'  OR `Banner ID` = '867548'  OR `Banner ID` = '578596'  OR `Banner ID` = '68223'  OR `Banner ID` = '563126'  OR `Banner ID` = '184688'  OR `Banner ID` = '844742'  OR `Banner ID` = '598516'  OR `Banner ID` = '613503'  OR `Banner ID` = '816062'  OR `Banner ID` = '421919'  OR `Banner ID` = '271802'  OR `Banner ID` = '144826' )
        // AND (Monday='M' OR Tuesday ='T'
        //       OR Wednesday= 'W' OR Thursday='H'
        //       OR Friday='F') ORDER BY find_in_set(Classification, 'Senior,Junior,Sophomore,Freshman')  ) as T GROUP BY `CRN` ORDER BY find_in_set(Classification, 'Senior,Junior,Sophomore,Freshman')
        

    // echo $query;
    $search = new DBQuery($query);
    $search->execute_query();
    $result = $search->get_result();
    $search->close();

    return $result;
}
function displayColor($classification,$class_st='',$class_et='',$start_time='',$end_time='',$D){
    $color =  "";
    if ( $class_et < $start_time || $class_st > $end_time || $D == '' ){
        $color = "Gray";
    }
    else if ($classification ==='Senior' ){
        $color="Red";
    }
    else if ($classification ==='Junior'){
        $color="#FF6103"; // orange
    }
    else if ($classification ==='Sophomore'){
        $color="#FCDC3B"; // yellow
    }
    else if($classification ==='Freshman'){
        $color="#385E0F"; //Green
    }

    return $color;
}
function createEvents($query_results = nil,$time=nil,$end_time=nil,$M='',$T='',$W='',$H='',$F=''){
    $rows_count = $query_results->num_rows;

    // echo $result['Course Title'];
    echo "events: [ ";
        for($i = 0; $i < $rows_count  ; $i++){
            $dow_time = '2014-12-08';

            $row = $query_results->fetch_assoc();
            if($row['Monday'] == 'M'){
                echo " {
                    id: '" . $row['CRN'] . "',
                    title: '" . $row['Course Title'] . "',
                    start: '" . $dow_time . intToISO($row['Begin Time 1']) ."',
                    end: '" . $dow_time . intToISO($row['End Time1']) .  "',
                    room: 'MBB 115',
                    instructor: '" . $row['Instructor Name'] . "',
                    color: '". displayColor($row['Classification'],$row['Begin Time 1'],$row['End Time1'],$time,$end_time,$M) ."',
                }," ;
            }
            $dow_time = incrementStartTime($dow_time);
            if($row['Tuesday'] == 'T'){
                echo " {
                    id: '" . $row['CRN'] . "',
                    title: '" . $row['Course Title'] . "',
                    start: '" . $dow_time . intToISO($row['Begin Time 1']) ."',
                    end: '" . $dow_time . intToISO($row['End Time1']) .  "',
                    room: 'MBB 115',
                    color: '". displayColor($row['Classification'],$row['Begin Time 1'],$row['End Time1'],$time,$end_time,$T) ."',
                }," ;
            }
            $dow_time = incrementStartTime($dow_time);
            if($row['Wednesday'] == 'W'){
                echo " {
                    id: " . $row['CRN'] . ",
                    title: '" . $row['Course Title'] . "',
                    start: '" . $dow_time . intToISO($row['Begin Time 1']) ."',
                    end: '" . $dow_time . intToISO($row['End Time1']) .  "',
                    room: 'MBB 115',
                    color: '". displayColor($row['Classification'],$row['Begin Time 1'],$row['End Time1'],$time,$end_time,$W) ."',
                }," ;
            }
            $dow_time = incrementStartTime($dow_time);
            if($row['Thursday'] == 'R'){
                echo " {
                    id: " . $row['CRN'] . ",
                    title: '" . $row['Course Title'] . "',
                    start: '" . $dow_time . intToISO($row['Begin Time 1']) ."',
                    end: '" . $dow_time . intToISO($row['End Time1']) .  "',
                    room: 'MBB 115',
                    color: '". displayColor($row['Classification'],$row['Begin Time 1'],$row['End Time1'],$time,$end_time,$H) ."',
                }," ;
            }
            $dow_time = incrementStartTime($dow_time);
            if($row['Friday'] == 'F'){
                echo " {
                    id: " . $row['CRN'] . ",
                    title: '" . $row['Course Title'] . "',
                    start: '" . $dow_time . intToISO($row['Begin Time 1']) ."',
                    end: '" . $dow_time . intToISO($row['End Time1']) .  "',
                    room: 'MBB 115',
                    color: '". displayColor($row['Classification'],$row['Begin Time 1'],$row['End Time1'],$time,$end_time,$F) ."',
                }," ;
            }
        }
    echo "],";
}

?>
